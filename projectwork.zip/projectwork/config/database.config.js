module.exports = {
    url: "mongodb+srv://abains8263:1234abains@cluster0-teifi.mongodb.net/test?retryWrites=true"
}
